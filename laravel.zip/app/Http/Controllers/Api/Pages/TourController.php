<?php

namespace App\Http\Controllers\Api\Pages;

use App\Http\Controllers\Controller;
use App\Models\Actividad;
use App\Models\Calificacion;
use App\Models\TourActividad;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Tour;

class TourController extends Controller
{
    // Obtener todos los tours
    public function getTours(Request $request)
    {
        $query = Tour::query();

        $query->whereHas('tourActividad');

        $tours = $query->get();

        // Procesar la portada y las fotos
        foreach ($tours as $tour) {
            // Agregar la ruta completa a la portada
            if (!empty($tour->portada)) {
                $tour->portada = url('storage/' . $tour->portada);
            }

            if ($tour && $tour->fotos) {
                // Convertir la cadena de fotos en un array y agregar las rutas completas
                $tour->fotos = collect(json_decode($tour->fotos))->map(function ($foto) {
                    return url('storage/' . $foto);
                });
            }
        }

        // Retornar los tours paginados
        return response()->json(['tours' => $tours]);
    }

    // Obtener un tour por ID
    public function getTourById(Request $request, $id)
    {
        $tour = Tour::find($id);
        if (!$tour) {
            return response()->json(['error' => 'Tour no encontrado'], 404);
        }
        $tourActividades = TourActividad::where('id_tour', $id)->get();
        $actividades = $tourActividades->map(function ($tourActividad) {
            // Obtener la actividad relacionada
            $actividad = Actividad::find($tourActividad->id_actividad);
            if ($actividad && $actividad->fotos) {
                $actividad->fotos = collect(json_decode($actividad->fotos))->map(function ($foto) {
                    return url('storage/' . $foto);
                });
            }

            // Obtener el guía relacionado con el tour (User)
            $guia = User::find($tourActividad->id_guia);
            if ($guia && $guia->avatar) {
                $guia->avatar = url('storage/' . $guia->avatar);
            }

            $promedioPuntuacion = Calificacion::where('id_tour_actividad', $tourActividad->id)
                ->avg('puntuacion');
            $tourActividad->makeHidden(['tour', 'actividad']);
            return [
                'actividad' => $actividad,
                'tour_actividad' => $tourActividad,
                'guia' => ['display' => $guia->display ?? null, 'avatar' => $guia->avatar ?? null],
                'promedio_puntuacion' => $promedioPuntuacion !== null ? round($promedioPuntuacion, 1) : null,
            ];
        });

        // Agregar la ruta completa a la portada
        if (!empty($tour->portada)) {
            $tour->portada = url('storage/' . $tour->portada);
        }
        // Convertir la cadena de fotos en un array y agregar las rutas completas
        $tour->fotos = collect(json_decode($tour->fotos))->map(function ($foto) {
            return url('storage/' . $foto);
        });

        return response()->json(['tour' => $tour, 'actividades' => $actividades]);
    }
}
