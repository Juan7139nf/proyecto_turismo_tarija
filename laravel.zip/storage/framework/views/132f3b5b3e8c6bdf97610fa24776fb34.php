<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', Voyager::setting("site.title")); ?></title>

    <?php $logo_favicon = Voyager::setting('site.logo', ''); ?>
    <?php if($logo_favicon == ''): ?>
        <link rel="shortcut icon" href="<?php echo e(voyager_asset('images/logo-icon.png')); ?>" type="image/png">
    <?php else: ?>
        <link rel="shortcut icon" href="<?php echo e(Voyager::image($logo_favicon)); ?>" type="image/png">
    <?php endif; ?>

    <link rel="stylesheet" href="../css/bootstrap.css">
    <script src="../js/bootstrap.js"></script>
    <style>
        /* Estilos específicos para la impresión */
        @media print {
            body {
                width: 100%;
                height: auto;
                margin: 0;
                padding: 0;
            }

            /* Configurar la orientación horizontal y el tamaño carta */
            @page {
                size: letter landscape;
                margin: 0;
            }

            /* Escalar la página al 60% */
            body {
                zoom: 60%;
            }

            .container-fluid {
                width: 100%;
            }

            /* Ajustar las tablas para impresión */
            table {
                width: 100%;
                border-collapse: collapse;
            }

            th,
            td {
                padding: 8px;
                text-align: left;
                border: 1px solid #ddd;
            }

            .table-dark th {
                background-color: #343a40;
                color: white;
            }
        }
    </style>
    <script>
        // Imprimir automáticamente al cargar la página
        window.onload = function () {
            window.print();
        };
    </script>
</head>

<body>
    <div class="container-fluid mt-5">
        <div class="d-flex justify-content-between">
            <h1 class="mb-4 fw-bold">Reporte de Reservas</h1>
            <div class="">
                <?php $logo = Voyager::setting('site.logo', ''); ?>
                <?php if($logo == ''): ?>
                    <img src="<?php echo e(voyager_asset('images/logo-icon.png')); ?>" alt="" style="max-width: 80px;">
                <?php else: ?>
                    <img src="<?php echo e(Voyager::image($logo)); ?>" alt="" style="max-width: 80px;">
                <?php endif; ?>
            </div>
        </div>
        <p class="text-small fw-bold">&copy; <?php echo e(setting('site.description')); ?> - 2025</p>
        <table class="table table-striped table-bordered border-black border-1">
            <thead>
                <tr class="text-center">
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Fecha creación</th>
                    <th>Duración</th>
                    <th>Destino</th>
                    <th>Tour actividad</th>
                    <th>Fecha inicio</th>
                    <th>Fecha fin</th>
                    <th>Precio</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($reserva->id); ?></td>
                        <td><?php echo e($reserva->turista ? $reserva->turista->display : 'Sin información del turista'); ?></td>
                        <td class="text-center"><?php echo e($reserva->created_at); ?></td>
                        <td class="text-end">
                            <?php echo e($reserva->tourActividad && $reserva->tourActividad->actividad->duracion ? $reserva->tourActividad->actividad->duracion . ' min' : 'Sin información'); ?>

                        </td>
                        <td><?php echo e($reserva->tourActividad && $reserva->tourActividad->tour->destino ? $reserva->tourActividad->tour->destino : 'Sin destino'); ?>

                        </td>
                        <td><?php echo e($reserva->tourActividad ? $reserva->tourActividad->display : 'Sin información del tour'); ?>

                        </td>
                        <td class="text-center">
                            <?php echo e($reserva->tourActividad && $reserva->tourActividad->tour->fecha_inicio ? $reserva->tourActividad->tour->fecha_inicio : 'Sin fecha'); ?>

                        </td>
                        <td class="text-center">
                            <?php echo e($reserva->tourActividad && $reserva->tourActividad->tour->fecha_fin ? $reserva->tourActividad->tour->fecha_fin : 'Sin fecha'); ?>

                        </td>
                        <td class="text-end">
                            <?php echo e($reserva->tourActividad ? $reserva->tourActividad->precio_total . ' Bs' : 'Sin información del precio'); ?>

                        </td>
                        <td class="text-center <?php echo e($reserva->estado == "Cancelado" ? "text-danger" : ""); ?>">
                            <?php echo e($reserva->estado); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH /home/vol7_4/infinityfree.com/if0_37385197/apiconpastel.infinityfreeapp.com/htdocs/laravel/resources/views/pdf/reserva.blade.php ENDPATH**/ ?>